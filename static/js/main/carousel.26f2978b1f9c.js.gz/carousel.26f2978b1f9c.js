$(document).ready(function() {
    $('.post-carousel').slick({
        autoplay: true,
        autoplaySpeed: 3000,
        arrows: false,
        vertical: true

    });
});